﻿namespace Bookstore.Models
{
    public class CartItemDTO
    {
        public int BookId { get; set; }
        public int Quantity { get; set; }
    }
}
